# scripts/synthetic_demo.jl
using Pkg
Pkg.activate("..")
using CSV, DataFrames, Random, Statistics, EWSF

function generate_data(n=1000)
    Random.seed!(123)
    age = randn(n) .* 10 .+ 50
    chol = randn(n) .* 30 .+ 200
    smoker = rand(n) .< 0.3
    smoker_s = ifelse.(smoker, "yes", "no")
    target = [ (age[i] > 52 || chol[i] > 240 || smoker[i]) ? "disease" : "healthy" for i in 1:n ]
    df = DataFrame(age=age, cholesterol=chol, smoker=smoker_s, target=target)
    return df
end

train = generate_data(800)
test = generate_data(200)

CSV.write("train_synthetic.csv", train)
CSV.write("test_synthetic.csv", test)

(df_clean, enc) = EWSF.EWSFData.data_preprocess(train, "target", ["age","cholesterol","smoker"]) 
model = EWSF.EWSFModel.train_ewsf(df_clean, enc; n_trees=60, n_subforests=3, max_depth=6)
println("Initial subforest weights: ", [sf.weight for sf in model.subforests])

function create_drifted(df)
    df2 = deepcopy(df)
    df2.age .= df2.age .+ 5.0
    for i in 1:nrow(df2)
        if rand() < 0.2
            df2.smoker[i] = "yes"
        end
    end
    return df2
end

incoming = create_drifted(test)
train_pre = df_clean
map_smoker = enc.feature_encoders[:smoker]
new_df = DataFrame(age = Float64[], cholesterol=Float64[], smoker=Int[])
for r in eachrow(incoming)
    push!(new_df, (Float64(r.age), Float64(r.cholesterol), get(map_smoker, r.smoker, 0)))
end
rename!(new_df, [:age, :cholesterol, :smoker])

summary = EWSF.EWSFModel.adapt_weights!(model, train_pre, new_df; p_threshold=0.05, n_perm=200, lambda=3.0)
println("Adaptation summary:\n", summary)
println("New weights: ", summary["new_weights"]) 
