module EWSF

# Public API
using CSV, DataFrames, CategoricalArrays, StatsBase, Random, Serialization, Statistics

include("utils.jl")
include("data.jl")
include("tree.jl")
include("model.jl")

export train_ewsf, predict_model, save_model, load_model, adapt_weights!, EWSFModel, SubForest

end # module
