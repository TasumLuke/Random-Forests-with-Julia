# run_predict.jl
using Pkg
Pkg.activate(".")
using CSV, DataFrames, Serialization, EWSF

model_path = readline(stdin; prompt="Model path: ")
model = open(model_path) do io; deserialize(io); end
csv_path = readline(stdin; prompt="CSV path to predict: ")
df = CSV.read(csv_path, DataFrame)
pred = EWSF.EWSFModel.predict_model(model, df)
out = readline(stdin; prompt="Output CSV path (predictions.csv): ")
if isempty(strip(out)); out = "predictions.csv"; end
CSV.write(out, pred)
println("Wrote predictions to ", out)
