# run_train.jl
using Pkg
Pkg.activate(".")
using CSV, DataFrames, Serialization, EWSF

# Simple interactive training wrapper
println("EWSF - interactive train")
path = readline(stdin; prompt="CSV path (or ENTER for sample_data.csv): ")
if isempty(strip(path))
    path = "sample_data.csv"
end
df = CSV.read(path, DataFrame)
println("Columns:")
for (i,c) in enumerate(names(df))
    println("[$i] ", c)
end
tidx = parse(Int, readline(stdin; prompt="Enter index of target column: "))
target = names(df)[tidx]
println("Enter comma-separated feature indices (or ENTER to use all other columns): ")
s = readline(stdin)
if isempty(strip(s))
    features = filter(c->c!=target, names(df))
else
    idxs = [ parse(Int, strip(x)) for x in split(s, ',') ]
    features = [ names(df)[i] for i in idxs if names(df)[i] != target ]
end
println("Preprocessing...")
(dfclean, enc) = EWSF.EWSFData.data_preprocess(df, string(target), string.(features))
model = EWSF.EWSFModel.train_ewsf(dfclean, enc)
out = readline(stdin; prompt="Save model filename (default ewsf_model.bin): ")
if isempty(strip(out))
    out = "ewsf_model.bin"
end
open(out, "w") do io; serialize(io, model); end
println("Saved model to ", out)
