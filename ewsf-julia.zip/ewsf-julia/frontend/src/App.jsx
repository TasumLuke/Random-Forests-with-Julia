import React, { useState } from "react";

export default function App() {
  const [uploading, setUploading] = useState(false);
  const [csvFile, setCsvFile] = useState(null);
  const [inspected, setInspected] = useState(null);
  const [target, setTarget] = useState(""); 
  const [features, setFeatures] = useState([]);
  const [modelPath, setModelPath] = useState(""); 
  const [status, setStatus] = useState(""); 
  const [predUrl, setPredUrl] = useState(""); 

  async function uploadCsv(ev) {
    const file = ev.target.files[0];
    if (!file) return;
    setUploading(true);
    const form = new FormData();
    form.append("file", file);
    try {
      const res = await fetch('http://localhost:3001/upload', { method: 'POST', body: form });
      const j = await res.json();
      setCsvFile(j.filename);
      setStatus("Uploaded: " + j.filename);
      await inspectCsv(j.filename);
    } catch (err) {
      console.error(err);
      setStatus("Upload failed");
    }
    setUploading(false);
  }

  async function inspectCsv(filename) {
    setStatus("Inspecting CSV...");
    const res = await fetch('http://localhost:3001/inspect', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ filename }) });
    const j = await res.json();
    setInspected(j);
    setStatus('Columns loaded');
    if (j.columns && j.columns.length > 0) setTarget(j.columns[j.columns.length-1]);
  }

  function toggleFeature(col) {
    if (features.includes(col)) setFeatures(features.filter(c => c !== col));
    else setFeatures([ ...features, col ]);
  }

  async function train() {
    if (!csvFile) { setStatus('Upload CSV first'); return; }
    if (!target) { setStatus('Select a target'); return; }
    if (features.length === 0) { setStatus('Select at least one feature'); return; }
    setStatus('Training...');
    const payload = {
      filename: csvFile,
      target,
      features,
      hyperparams: { n_trees: 90, max_depth: 8, min_leaf: 3, n_subforests: 3 }
    };
    const res = await fetch('http://localhost:3001/train', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(payload) });
    const j = await res.json();
    if (j.status === 'ok') {
      setModelPath(j.model);
      setStatus('Trained. Model saved: ' + j.model);
    } else {
      setStatus('Training failed: ' + (j.error || 'unknown'));
    }
  }

  async function uploadForPredict(ev) {
    const file = ev.target.files[0];
    if (!file) return;
    const form = new FormData();
    form.append('file', file);
    setStatus('Uploading prediction CSV...');
    const res = await fetch('http://localhost:3001/upload_predict', { method: 'POST', body: form });
    const j = await res.json();
    if (j.filename) {
      setStatus('Uploaded for prediction: ' + j.filename);
      await predict(j.filename);
    }
  }

  async function predict(filename) {
    if (!modelPath) { setStatus('No model selected'); return; }
    setStatus('Predicting...');
    const res = await fetch('http://localhost:3001/predict', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ filename, model: modelPath }) });
    const j = await res.json();
    if (j.status === 'ok') {
      setPredUrl(j.predictions_url);
      setStatus('Predictions ready');
    } else {
      setStatus('Predict failed: ' + (j.error || 'unknown'));
    }
  }

  return (
    <div style={{padding:20, maxWidth:900}}>
      <h1 style={{fontSize:24}}>EWSF — Upload CSV & Train (GUI)</h1>
      <div style={{marginTop:10}}>
        <label>Upload CSV (training)</label><br/>
        <input type="file" accept=".csv" onChange={uploadCsv} />
        <div style={{color:'#666', marginTop:6}}>{status}</div>
      </div>

      {inspected && (
        <div style={{marginTop:20}}>
          <h2>Columns</h2>
          <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:8}}>
            {inspected.columns.map(col => (
              <div key={col} style={{border:'1px solid #ddd', padding:8, borderRadius:6}}>
                <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
                  <div>{col}</div>
                  <div>
                    <input type="checkbox" checked={features.includes(col)} onChange={()=>toggleFeature(col)} /> Feature
                  </div>
                </div>
                <div style={{marginTop:6, fontSize:12, color:'#666'}}>Preview: {inspected.preview && inspected.preview.map(r=>r[col]).slice(0,3).join(', ')}</div>
              </div>
            ))}
          </div>

          <div style={{marginTop:12}}>
            <label>Target column</label>
            <select value={target} onChange={(e)=>setTarget(e.target.value)} style={{marginLeft:8}}>
              {inspected.columns.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>

          <div style={{marginTop:12}}>
            <button onClick={train} style={{padding:'8px 12px', background:'#1f6feb', color:'#fff', borderRadius:6}}>Train model</button>
            <div style={{marginTop:8}}>Trained model path: {modelPath}</div>
          </div>
        </div>
      )}

      <hr style={{marginTop:20}} />

      <div style={{marginTop:12}}>
        <h2>Predict on new CSV</h2>
        <input type="file" accept=".csv" onChange={uploadForPredict} />
        {predUrl && <div style={{marginTop:8}}>Download predictions: <a href={predUrl} target="_blank" rel="noreferrer">{predUrl}</a></div>}
      </div>

    </div>
  );
}
